﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using corewebapivs2017.Models;

namespace corewebapivs2017.Controllers
{
    [Route("api/[controller]")]
    // [ApiController]
    public class TodoController : Controller
    {
        private readonly TodoContext _context;

        public TodoController(TodoContext context)
        {
            _context = context;

            // if (_context.TodoItems.Count() == 0)
            // {
            //     _context.TodoItems.Add(new TodoItem { Name = "Item1" });
            //     _context.SaveChanges();
            // }
        }

        //public IActionResult Index()
        //{
        //    return View();
        //}

        [HttpGet]
        public List<TodoItem> GetAll()
        {
            return _context.TodoItems.ToList();
            //return new ObjectResult(_context.TodoItems.ToList());
        }

        [HttpGet("{id}", Name = "GetTodo")]
        public TodoItem GetById(long id)
        {
            var item = _context.TodoItems.Find(id);
            if (item == null)
            {
                return null;
            }
            return item;
            //return new ObjectResult(item);
        }
    }
}